import { useMemo, useState } from 'react';
import Header from '@/components/Header';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, Legend, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import { useRegistroAndonSupabase } from '@/hooks/useRegistroAndonSupabase';

export default function Relatorio() {
  const { registros, loading } = useRegistroAndonSupabase();

  // Filtragem básica por período (ex: últimos 7 dias ou todos)
  const [diasFiltro, setDiasFiltro] = useState<number>(7);

  const construtorTurno = (dataString: string) => {
    const d = new Date(dataString);
    const hour = d.getHours();
    if (hour >= 6 && hour < 15) return 'T1 (Manhã)';
    if (hour >= 15 && hour < 23) return 'T2 (Tarde)';
    return 'T3 (Noite)';
  };

  const dadosGraficos = useMemo(() => {
    if (!registros.length) return { porTacto: [], porTurno: [] };

    const agora = new Date().getTime();
    const millisFiltro = diasFiltro === 0 ? 0 : diasFiltro * 24 * 60 * 60 * 1000;

    const registrosFiltrados = registros.filter(r => {
      if (millisFiltro === 0) return true;
      const t = new Date(r.criado_em).getTime();
      return (agora - t) <= millisFiltro;
    });

    const countsPorTacto: Record<number, number> = {};
    const countsPorTurno: Record<string, number> = { 'T1 (Manhã)': 0, 'T2 (Tarde)': 0, 'T3 (Noite)': 0 };

    registrosFiltrados.forEach(r => {
      countsPorTacto[r.tacto] = (countsPorTacto[r.tacto] || 0) + 1;

      const turno = construtorTurno(r.criado_em);
      countsPorTurno[turno] += 1;
    });

    const porTacto = Object.entries(countsPorTacto)
      .map(([tacto, qt]) => ({ name: `Tacto ${tacto}`, quantidade: qt }))
      .sort((a, b) => b.quantidade - a.quantidade);

    const porTurno = Object.entries(countsPorTurno)
      .map(([turno, qt]) => ({ name: turno, value: qt }));

    return { porTacto, porTurno, total: registrosFiltrados.length };
  }, [registros, diasFiltro]);

  if (loading) {
    return <div className="p-8 text-center text-[#001E50] font-black text-xl">Calculando KPI...</div>;
  }

  const COLORS = ['#001E50', '#004A99', '#7FA2D6'];

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header title="Relatórios Andon" showBackButton={true} />

      <main className="flex-1 max-w-6xl w-full mx-auto p-6 space-y-8">

        <div className="text-center pb-6 border-b-2 border-gray-100">
          <h2 className="text-4xl font-black text-[#001E50] uppercase tracking-tighter">Volume de Pedidos</h2>
          <p className="text-gray-500 font-bold mt-2">Visão Estratégica</p>
        </div>

        <div className="flex gap-4 mb-8 max-w-sm mx-auto">
          <select
            className="w-full bg-white border-2 border-[#001E50] text-[#001E50] font-black p-4 rounded-xl shadow-md outline-none focus:ring-0"
            value={diasFiltro}
            onChange={(e) => setDiasFiltro(Number(e.target.value))}
          >
            <option value={1}>Últimas 24 horas</option>
            <option value={7}>Últimos 7 dias</option>
            <option value={30}>Últimos 30 dias</option>
            <option value={0}>Todo o Histórico</option>
          </select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">

          <div className="bg-white p-6 md:p-8 rounded-3xl border-4 border-gray-100 shadow-[8px_8px_0px_#E5E7EB]">
            <h3 className="text-2xl font-black text-[#001E50] mb-6 uppercase tracking-wider">Por Tacto</h3>
            <div className="h-80 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={dadosGraficos.porTacto}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="name" tick={{ fill: '#6B7280', fontWeight: 'bold' }} axisLine={false} tickLine={false} />
                  <YAxis tick={{ fill: '#6B7280', fontWeight: 'bold' }} axisLine={false} tickLine={false} />
                  <RechartsTooltip cursor={{ fill: '#F3F4F6' }} contentStyle={{ borderRadius: '12px', fontWeight: 'bold' }} />
                  <Bar dataKey="quantidade" fill="#001E50" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          <div className="bg-white p-6 md:p-8 rounded-3xl border-4 border-gray-100 shadow-[8px_8px_0px_#E5E7EB] flex flex-col">
            <h3 className="text-2xl font-black text-[#001E50] mb-6 uppercase tracking-wider text-center">Por Turno</h3>
            <div className="flex-1 min-h-[300px] w-full relative">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={dadosGraficos.porTurno}
                    cx="50%"
                    cy="50%"
                    innerRadius={80}
                    outerRadius={120}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {dadosGraficos.porTurno.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <RechartsTooltip contentStyle={{ borderRadius: '12px', fontWeight: 'bold', border: 'none', boxShadow: '0 10px 25px -5px rgba(0,0,0,0.1)' }} />
                  <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{ fontWeight: 'bold', color: '#111827' }} />
                </PieChart>
              </ResponsiveContainer>
              <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none pb-8 text-[#001E50]">
                <span className="text-4xl font-black">{dadosGraficos.total}</span>
                <span className="text-xs font-bold text-gray-400 uppercase tracking-widest">Total</span>
              </div>
            </div>
          </div>

        </div>

      </main>
    </div>
  );
}

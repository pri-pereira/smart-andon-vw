import { useLocation } from 'wouter';
import { useAuthRE } from '@/hooks/useAuthRE';
import { Truck, HardHat, FileText, HelpCircle, ArrowRight, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Home() {
  const [, setLocation] = useLocation();
  const { user } = useAuthRE();

  return (
    <div className="min-h-screen bg-white flex flex-col items-center">
      {/* Cabeçalho */}
      <header className="w-full bg-[#001E50] p-6 flex items-center shadow-md">
        {/* Placeholder para o logo */}
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-black text-[#001E50]">VW</div>
          <h1 className="text-2xl font-black text-white tracking-widest uppercase">Smart Andon</h1>
        </div>
      </header>

      {/* Conteúdo Principal */}
      <main className="flex-1 w-full max-w-5xl p-6 flex flex-col justify-center gap-12">
        <div className="text-center">
          <h2 className="text-5xl font-black text-[#001E50]">Célula Vidros</h2>
          <div className="w-24 h-1 bg-[#001E50] mx-auto mt-6"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 w-full max-w-4xl mx-auto">
          {/* Botão Operador */}
          <button
            onClick={() => setLocation('/operador')}
            className="group flex flex-col items-center justify-center bg-white border-4 border-[#001E50] p-16 rounded-[2rem] hover:bg-[#001E50] hover:text-white transition-all shadow-xl active:scale-95 text-[#001E50]"
          >
            <HardHat size={80} className="mb-6 group-hover:text-white transition-colors" />
            <h3 className="text-4xl font-black uppercase tracking-wide">Operador</h3>
            <p className="mt-4 font-bold opacity-70">Acesso da Linha</p>
          </button>

          {/* Botão Logística */}
          <button
            onClick={() => setLocation('/login')}
            className="group flex flex-col items-center justify-center bg-[#001E50] border-4 border-[#001E50] p-16 rounded-[2rem] hover:bg-[#002E7A] transition-all shadow-xl active:scale-95 text-white"
          >
            <Truck size={80} className="mb-6" />
            <h3 className="text-4xl font-black uppercase tracking-wide">Logística</h3>
            <p className="mt-4 font-bold text-blue-200">Acesso via Rota</p>
          </button>
        </div>
      </main>

      {/* Rodapé com atalho ADM */}
      <footer className="w-full py-6 mt-12 bg-gray-50 border-t-2 border-gray-100 flex flex-wrap justify-center items-center gap-8 text-sm font-bold text-[#131314]">
        <button onClick={() => setLocation('/ajuda')} className="flex items-center hover:text-[#001E50] transition-colors">
          <HelpCircle size={18} className="mr-2" /> Ajuda
        </button>
        <div className="w-1 h-1 bg-gray-300 rounded-full hidden md:block"></div>
        <button onClick={() => setLocation('/relatorio')} className="flex items-center hover:text-[#001E50] transition-colors">
          <FileText size={18} className="mr-2" /> Relatórios
        </button>

        <div className="w-1 h-1 bg-gray-300 rounded-full hidden md:block"></div>

        {/* Atalho ADM */}
        <Button
          variant="outline"
          onClick={() => setLocation('/admin')}
          className="flex items-center border-[#001E50] text-[#001E50] hover:bg-[#001E50] hover:text-white rounded-full px-6 transition-all shadow-sm"
        >
          <Settings size={16} className="mr-2" /> ADM do Catálogo
        </Button>
      </footer>
    </div>
  );
}

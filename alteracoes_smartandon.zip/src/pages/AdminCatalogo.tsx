import { useState } from 'react';
import { useLocation } from 'wouter';
import { Settings, Plus, Trash2, Edit2, ChevronLeft } from 'lucide-react';
import Header from '@/components/Header';
import { useCatalogoPecas } from '@/hooks/useCatalogoPecas';
import { type CatalogoPeca } from '@/lib/supabase';

export default function AdminCatalogo() {
  const [, setLocation] = useLocation();
  const { pecas, loading, adicionarPeca, editarPeca, removerPeca } = useCatalogoPecas();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formData, setFormData] = useState<Omit<CatalogoPeca, 'id'>>({
    codigo: '',
    nome: '',
    tacto: 1,
    cor_logistica: 'branco',
    centro_custo: 'CC: 19087'
  });

  const abrirModalParaAdicionar = () => {
    setFormData({ codigo: '', nome: '', tacto: 1, cor_logistica: 'branco', centro_custo: 'CC: 19087' });
    setEditingId(null);
    setIsModalOpen(true);
  };

  const abrirModalParaEditar = (peca: CatalogoPeca) => {
    setFormData({
      codigo: peca.codigo,
      nome: peca.nome,
      tacto: peca.tacto,
      cor_logistica: peca.cor_logistica,
      centro_custo: peca.centro_custo || '',
    });
    setEditingId(peca.id);
    setIsModalOpen(true);
  };

  const handleSalvar = async () => {
    if (!formData.codigo || !formData.nome) return alert('Preencha os campos obrigatórios');

    if (editingId) {
      await editarPeca(editingId, formData);
    } else {
      await adicionarPeca(formData);
    }

    setIsModalOpen(false);
  };

  const handleExcluir = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir esta peça?')) {
      await removerPeca(id);
    }
  };

  if (loading) return <div className="p-8 text-center text-[#001E50] font-black text-xl">Carregando...</div>;

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header title="Gestão do Catálogo" showBackButton={true} />

      <main className="flex-1 max-w-6xl w-full mx-auto p-6 space-y-8">
        <div className="flex justify-between items-center bg-white p-6 rounded-3xl shadow-sm border-2 border-gray-100">
          <div>
            <h2 className="text-3xl font-black text-[#001E50] flex items-center gap-3">
              <Settings className="text-[#001E50]" size={36} />
              Catálogo Célula Vidros
            </h2>
            <p className="text-gray-500 font-bold mt-1">Total de Peças Ativas: {pecas.length}</p>
          </div>
          <button
            onClick={abrirModalParaAdicionar}
            className="bg-[#001E50] hover:bg-[#002E7A] text-white px-8 py-4 rounded-2xl font-black shadow-lg flex items-center gap-2 active:scale-95 transition-all"
          >
            <Plus size={24} /> Nova Peça
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pecas.map(peca => (
            <div key={peca.id} className="bg-white border-4 border-[#131314] rounded-3xl p-6 shadow-[8px_8px_0px_#131314]">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="text-xl font-black uppercase text-[#001E50]">{peca.nome}</h3>
                  <p className="font-mono font-bold text-gray-500">{peca.codigo}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-black uppercase border-2`}
                  style={{
                    backgroundColor: peca.cor_logistica === 'rosa' ? '#FDF2F8' : peca.cor_logistica === 'azul' ? '#EFF6FF' : peca.cor_logistica === 'amarelo' ? '#FEFCE8' : '#FFFFFF',
                    borderColor: peca.cor_logistica === 'rosa' ? '#FBCFE8' : peca.cor_logistica === 'azul' ? '#BFDBFE' : peca.cor_logistica === 'amarelo' ? '#FEF08A' : '#E5E7EB',
                    color: peca.cor_logistica === 'rosa' ? '#831843' : peca.cor_logistica === 'azul' ? '#1E3A8A' : peca.cor_logistica === 'amarelo' ? '#713F12' : '#111827',
                  }}
                >
                  {peca.cor_logistica}
                </div>
              </div>

              <div className="flex gap-4 p-4 bg-gray-50 rounded-2xl mb-6">
                <div>
                  <p className="text-xs font-bold text-gray-400 uppercase">Tacto</p>
                  <p className="font-black text-xl text-[#001E50]">{peca.tacto}</p>
                </div>
                <div className="border-l-2 border-gray-200"></div>
                <div>
                  <p className="text-xs font-bold text-gray-400 uppercase">Centro de Custo</p>
                  <p className="font-black text-xl text-[#001E50]">{peca.centro_custo || '-'}</p>
                </div>
              </div>

              <div className="flex gap-3 mt-4">
                <button
                  onClick={() => abrirModalParaEditar(peca)}
                  className="flex-1 py-3 bg-gray-100 hover:bg-gray-200 text-[#001E50] font-black rounded-xl flex items-center justify-center gap-2"
                >
                  <Edit2 size={18} /> Editar
                </button>
                <button
                  onClick={() => handleExcluir(peca.id)}
                  className="py-3 px-4 bg-red-50 hover:bg-red-100 text-red-600 font-black rounded-xl"
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      </main>

      {/* Modal Genérico Add/Edit */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-[#131314]/50 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-xl p-8 border-4 border-[#001E50] shadow-[0_20px_60px_-15px_rgba(0,0,0,0.5)]">
            <h2 className="text-3xl font-black text-[#001E50] mb-6">{editingId ? 'Editar Peça' : 'Nova Peça'}</h2>

            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1 uppercase tracking-widest">Código</label>
                  <input
                    type="text" value={formData.codigo} onChange={e => setFormData({ ...formData, codigo: e.target.value })}
                    className="w-full border-2 border-gray-200 rounded-xl p-3 font-bold focus:border-[#001E50]"
                    placeholder="Ex: 5G0 941 700"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1 uppercase tracking-widest">Tacto</label>
                  <input
                    type="number" value={formData.tacto} onChange={e => setFormData({ ...formData, tacto: Number(e.target.value) })}
                    className="w-full border-2 border-gray-200 rounded-xl p-3 font-bold focus:border-[#001E50]"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-bold text-gray-500 mb-1 uppercase tracking-widest">Nome da Peça</label>
                <input
                  type="text" value={formData.nome} onChange={e => setFormData({ ...formData, nome: e.target.value })}
                  className="w-full border-2 border-gray-200 rounded-xl p-3 font-bold focus:border-[#001E50]"
                  placeholder="Ex: Farol Dianteiro LE"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1 uppercase tracking-widest">Custo</label>
                  <input
                    type="text" value={formData.centro_custo} onChange={e => setFormData({ ...formData, centro_custo: e.target.value })}
                    className="w-full border-2 border-gray-200 rounded-xl p-3 font-bold focus:border-[#001E50]"
                  />
                </div>
                <div>
                  <label className="block text-sm font-bold text-gray-500 mb-1 uppercase tracking-widest">Cor Lógica</label>
                  <select
                    value={formData.cor_logistica} onChange={e => setFormData({ ...formData, cor_logistica: e.target.value as any })}
                    className="w-full border-2 border-gray-200 rounded-xl p-3 font-bold focus:border-[#001E50] bg-white outline-none"
                  >
                    <option value="azul">Azul</option>
                    <option value="rosa">Rosa</option>
                    <option value="amarelo">Amarelo</option>
                    <option value="branco">Branco</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex gap-4 mt-8 pt-6 border-t-2 border-gray-100">
              <button
                onClick={() => setIsModalOpen(false)}
                className="flex-1 py-4 bg-gray-100 font-black text-gray-500 rounded-2xl hover:bg-gray-200"
              >
                Cancelar
              </button>
              <button
                onClick={handleSalvar}
                className="flex-1 py-4 bg-[#001E50] font-black text-white rounded-2xl hover:bg-[#002E7A] shadow-lg"
              >
                Salvar Peça
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

import { useEffect, useState, useRef } from 'react';
import Header from '@/components/Header';
import AlertaTacto from '@/components/AlertaTacto';
import { useRegistroAndonSupabase } from '@/hooks/useRegistroAndonSupabase';
import { useAuthRE } from '@/hooks/useAuthRE';
import { playPing } from '@/lib/audio';
import { CheckCircle2, PackageCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export default function LogisticaSupabase() {
  const { registros, loading, error, sinalizarEntrega } = useRegistroAndonSupabase();
  const { user } = useAuthRE();
  const [entregandoId, setEntregandoId] = useState<string | null>(null);

  // Ref para detectar novos registros e tocar o Ping
  const numRegistrosPendentesRef = useRef<number>(0);

  const pendentes = registros.filter(r => r.status === 'pendente');
  const emTransito = registros.filter(r => r.status === 'em_transito');
  const concluidos = registros.filter(r => r.status === 'concluido');

  useEffect(() => {
    // Se aumentou o número de pendentes, toca o ping
    if (pendentes.length > numRegistrosPendentesRef.current) {
      playPing();
    }
    numRegistrosPendentesRef.current = pendentes.length;
  }, [pendentes.length]);

  const handleEntregaRealizada = async (id: string) => {
    setEntregandoId(id);
    await sinalizarEntrega(id);
    setEntregandoId(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-white flex flex-col items-center justify-center">
        <div className="animate-spin h-12 w-12 border-4 border-[#001E50] border-t-transparent rounded-full" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white flex flex-col">
      <Header title="Dashboard - Logística" showBackButton={true} />

      <main className="flex-1 p-4 md:p-6 pb-20 max-w-6xl mx-auto w-full">
        <div className="space-y-6">
          <div className="text-center pb-6 border-b-2 border-gray-100">
            <h2 className="text-4xl font-black text-[#001E50] tracking-tight uppercase">Monitoramento</h2>
            <p className="text-[#6B7280] font-bold">Resumo Célula Vidros • Dia Atual</p>
          </div>

          <div className="flex gap-4">
            <div className="flex-1 bg-red-50 border-2 border-red-100 rounded-3xl p-6 text-center">
              <p className="font-bold text-red-900 uppercase">Aguardando Logística</p>
              <p className="text-4xl font-black text-red-600">{pendentes.length}</p>
            </div>
            <div className="flex-1 bg-blue-50 border-2 border-blue-100 rounded-3xl p-6 text-center">
              <p className="font-bold text-blue-900 uppercase">Aguardando Operador</p>
              <p className="text-4xl font-black text-blue-600">{emTransito.length}</p>
            </div>
            <div className="flex-1 bg-green-50 border-2 border-green-100 rounded-3xl p-6 text-center">
              <p className="font-bold text-green-900 uppercase">Concluídos</p>
              <p className="text-4xl font-black text-green-600">{concluidos.length}</p>
            </div>
          </div>

          <div className="space-y-4 pt-6">
            <h3 className="text-2xl font-black text-[#001E50]">Entregas Pendentes</h3>

            <AnimatePresence>
              {pendentes.map(registro => (
                <motion.div
                  key={registro.id}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: 20 }}
                  className="bg-white border-4 border-[#131314] rounded-2xl p-6 flex flex-col md:flex-row items-center gap-6 shadow-[8px_8px_0px_#131314]"
                >
                  <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4 w-full text-center">
                    <div className="bg-gray-100 rounded-xl p-3 border-2 border-gray-300">
                      <p className="text-xs font-bold text-gray-500 uppercase">Tacto</p>
                      <p className="text-2xl font-black text-[#001E50]">{registro.tacto}</p>
                    </div>
                    <div className="bg-gray-100 rounded-xl p-3 border-2 border-gray-300">
                      <p className="text-xs font-bold text-gray-500 uppercase">Lado</p>
                      <p className="text-2xl font-black text-[#001E50]">{registro.lado}</p>
                    </div>
                    <div className="bg-gray-100 rounded-xl p-3 border-2 border-gray-300 col-span-2 md:col-span-1">
                      <p className="text-xs font-bold text-gray-500 uppercase">Peça</p>
                      <p className="text-lg font-black text-[#001E50] uppercase leading-tight mt-1">{registro.peca?.nome || registro.peca_id}</p>
                    </div>
                    <div className="bg-gray-100 rounded-xl p-3 border-2 border-gray-300 col-span-2 md:col-span-1">
                      <p className="text-xs font-bold text-gray-500 uppercase">{registro.peca?.centro_custo || 'CC'}</p>
                      <p className="text-lg font-mono font-bold text-[#001E50] mt-1">{registro.peca?.codigo}</p>
                    </div>
                  </div>

                  <div className="flex flex-col items-center justify-center min-w-[200px] w-full md:w-auto">
                    <AlertaTacto dataCriacao={registro.criado_em} status={registro.status} />
                  </div>

                  <button
                    onClick={() => handleEntregaRealizada(registro.id)}
                    disabled={entregandoId === registro.id}
                    className="w-full md:w-auto bg-[#001E50] hover:bg-[#002E7A] text-white font-black px-8 py-6 rounded-2xl shadow-xl flex items-center justify-center gap-3 active:scale-95 transition-all outline-none disabled:opacity-50"
                  >
                    <PackageCheck size={28} />
                    {entregandoId === registro.id ? 'Aguarde...' : 'Entrega Realizada'}
                  </button>
                </motion.div>
              ))}
            </AnimatePresence>

            {pendentes.length === 0 && (
              <div className="text-center p-12 bg-gray-50 rounded-2xl border-4 border-dashed border-gray-200">
                <CheckCircle2 size={48} className="text-gray-400 mx-auto mb-4" />
                <p className="text-2xl font-black text-gray-500">Nenhum chamado pendente</p>
              </div>
            )}
          </div>

          {(emTransito.length > 0 || concluidos.length > 0) && (
            <div className="space-y-4 pt-10 opacity-70">
              <h3 className="text-xl font-bold text-gray-500 uppercase tracking-widest">Histórico Recente</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {emTransito.map(registro => (
                  <div key={registro.id} className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-4 flex gap-4 items-center">
                    <div className="bg-blue-100 p-3 rounded-full text-blue-600">
                      <PackageCheck size={24} />
                    </div>
                    <div>
                      <p className="font-bold text-blue-900">Aguardando Operador Confirmar</p>
                      <p className="text-sm font-bold text-blue-700">{registro.peca?.nome} (Tacto {registro.tacto} • Lado {registro.lado})</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

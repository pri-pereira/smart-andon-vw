import { useState, useMemo, useEffect } from 'react';
import { useLocation } from 'wouter';
import { ArrowLeft, Box, CheckCircle2, PackageCheck } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import Header from '@/components/Header';
import { useAuthRE } from '@/hooks/useAuthRE';
import { useRegistroAndonSupabase } from '@/hooks/useRegistroAndonSupabase';
import { useCatalogoPecas } from '@/hooks/useCatalogoPecas';
import { playSoftAlert } from '@/lib/audio';
import { type CatalogoPeca } from '@/lib/supabase';

// Helper de Cores Logísticas VW Célula Vidros
function getCardStyle(cor: string) {
  switch (cor.toLowerCase()) {
    case 'rosa': return 'bg-[#FDF2F8] border-[#FBCFE8] text-pink-900';
    case 'azul': return 'bg-[#EFF6FF] border-[#BFDBFE] text-blue-900';
    case 'amarelo': return 'bg-[#FEFCE8] border-[#FEF08A] text-yellow-900';
    case 'branco': return 'bg-white border-gray-200 text-gray-900';
    default: return 'bg-white border-gray-200 text-gray-900';
  }
}

export default function OperadorSupabase() {
  const [, setLocation] = useLocation();
  const { user, login } = useAuthRE();
  const { registros, adicionarRegistro, confirmarRecebimento } = useRegistroAndonSupabase();
  const { pecas } = useCatalogoPecas();

  const [step, setStep] = useState<'login' | 'config' | 'catalogo'>('login');
  const [reInput, setReInput] = useState('');
  const [tactoSelecionado, setTactoSelecionado] = useState<number | ''>('');
  const [ladoSelecionado, setLadoSelecionado] = useState<'LE' | 'LD' | null>(null);
  const [pecaConfirmando, setPecaConfirmando] = useState<CatalogoPeca | null>(null);

  // Monitoramento para Double-Check
  const entregasRecebidas = useMemo(() => {
    return registros.filter(
      r => r.status === 'em_transito' && r.tacto === Number(tactoSelecionado) && r.lado === ladoSelecionado
    );
  }, [registros, tactoSelecionado, ladoSelecionado]);

  // Efeito para tocar som quando nova entrega em trânsito surgir
  useEffect(() => {
    if (entregasRecebidas.length > 0) {
      // Dispara o alerta
      playSoftAlert();
    }
  }, [entregasRecebidas.length]);

  useEffect(() => {
    if (user) setStep('config');
    else setStep('login');
  }, [user]);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (reInput.trim().length > 3) {
      if (login(reInput)) setStep('config');
    }
  };

  const handleConfirmarConfig = () => {
    if (tactoSelecionado && ladoSelecionado) setStep('catalogo');
  };

  const handleLimparConfig = () => {
    setTactoSelecionado('');
    setLadoSelecionado(null);
  };

  const handlePedir = async () => {
    if (!pecaConfirmando || !tactoSelecionado || !ladoSelecionado) return;
    await adicionarRegistro(Number(tactoSelecionado), ladoSelecionado, pecaConfirmando.id);
    setPecaConfirmando(null);
  };

  const handleChegou = async (id: string, event: React.MouseEvent) => {
    event.stopPropagation();
    await confirmarRecebimento(id);
  };

  // Filtrar o catálogo de acordo com o Tacto digitado (se tacto estrito)
  const pecasExibidas = pecas.filter(p => !tactoSelecionado || p.tacto === Number(tactoSelecionado));

  return (
    <div className="min-h-screen bg-white">
      <Header title="Operador Andon" showNav={false} />

      <main className="max-w-4xl mx-auto p-4 md:p-6 pb-32">
        <AnimatePresence mode="wait">

          {/* STEP LOGIN */}
          {step === 'login' && (
            <motion.div key="login" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="pt-20">
              <div className="w-full max-w-sm mx-auto bg-white border border-gray-100 shadow-[0_10px_40px_-10px_rgba(0,30,80,0.15)] rounded-3xl p-8">
                <Box className="w-16 h-16 text-[#001E50] mx-auto mb-6" />
                <h2 className="text-3xl font-black text-[#001E50] text-center mb-8">Login RE</h2>
                <form onSubmit={handleLogin} className="space-y-6">
                  <input
                    type="number"
                    value={reInput}
                    onChange={(e) => setReInput(e.target.value)}
                    placeholder="RE"
                    className="w-full text-center text-4xl font-black text-[#001E50] py-4 border-2 border-gray-200 rounded-2xl focus:border-[#001E50]"
                    autoFocus
                  />
                  <button
                    type="submit"
                    disabled={!reInput}
                    className="w-full py-4 bg-[#001E50] text-white font-bold text-lg rounded-2xl disabled:opacity-50"
                  >
                    Entrar
                  </button>
                </form>
              </div>
            </motion.div>
          )}

          {/* STEP CONFIG */}
          {step === 'config' && (
            <motion.div key="config" initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} className="space-y-8 max-w-md mx-auto pt-10">
              <div className="text-center">
                <h2 className="text-4xl font-black text-[#001E50] uppercase">Configuração</h2>
                <p className="text-gray-500 font-bold mt-2">Defina sua posição na Célula</p>
              </div>

              <div className="bg-white border border-gray-100 shadow-[0_10px_40px_-10px_rgba(0,30,80,0.1)] p-8 rounded-3xl space-y-8">
                <div>
                  <label className="block text-xl font-bold text-[#001E50] mb-4">Número do Tacto</label>
                  <input
                    type="number"
                    value={tactoSelecionado}
                    onChange={(e) => setTactoSelecionado(Number(e.target.value) || '')}
                    className="w-full text-center text-5xl font-black text-[#001E50] py-6 border-2 border-gray-200 rounded-2xl focus:border-[#001E50] focus:ring-0 transition-colors"
                  />
                </div>

                <div>
                  <label className="block text-xl font-bold text-[#001E50] mb-4">Lado e Posição</label>
                  <div className="flex gap-4 w-full">
                    <button
                      onClick={() => setLadoSelecionado('LE')}
                      className={`flex-1 w-1/2 rounded-2xl border-2 py-8 font-black text-2xl transition-all shadow-sm ${ladoSelecionado === 'LE' ? 'bg-[#001E50] text-white border-[#001E50]' : 'bg-gray-50 text-[#001E50] border-gray-200 hover:border-[#001E50]/50'}`}
                    >
                      LE - Lado Esquerdo
                    </button>
                    <button
                      onClick={() => setLadoSelecionado('LD')}
                      className={`flex-1 w-1/2 rounded-2xl border-2 py-8 font-black text-2xl transition-all shadow-sm ${ladoSelecionado === 'LD' ? 'bg-[#001E50] text-white border-[#001E50]' : 'bg-gray-50 text-[#001E50] border-gray-200 hover:border-[#001E50]/50'}`}
                    >
                      LD - Lado Direito
                    </button>
                  </div>
                </div>

                <div className="flex gap-4 pt-4 border-t-2 border-gray-100">
                  <button
                    onClick={handleLimparConfig}
                    className="flex-1 py-5 bg-gray-100 text-[#001E50] font-bold text-xl rounded-2xl hover:bg-gray-200"
                  >
                    Limpar
                  </button>
                  <button
                    onClick={handleConfirmarConfig}
                    disabled={!tactoSelecionado || !ladoSelecionado}
                    className="flex-1 py-5 bg-[#001E50] text-white font-bold text-xl rounded-2xl disabled:opacity-50 active:scale-95"
                  >
                    Confirmar
                  </button>
                </div>
              </div>
            </motion.div>
          )}

          {/* STEP CATALOGO */}
          {step === 'catalogo' && (
            <motion.div key="catalogo" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="space-y-6">

              <div className="flex items-center justify-between mt-4 mb-4 pb-4 border-b-2 border-gray-100">
                <button
                  onClick={() => setStep('config')}
                  className="p-4 bg-gray-100 text-[#001E50] rounded-full hover:bg-gray-200 shadow-sm transition-transform"
                >
                  <ArrowLeft className="w-6 h-6" />
                </button>
                <div className="text-center">
                  <h2 className="text-3xl font-black text-[#001E50] uppercase tracking-tighter">Catálogo de Peças</h2>
                  <p className="font-bold text-gray-500 bg-gray-100 px-4 py-1 rounded-full inline-block mt-2">
                    Tacto {tactoSelecionado} • Lado {ladoSelecionado}
                  </p>
                </div>
                <div className="w-14"></div>
              </div>

              {/* Automatic Modal (Double-Check Overlay) */}
              <AnimatePresence>
                {entregasRecebidas.map(r => (
                  <motion.div
                    key={r.id}
                    initial={{ opacity: 0, y: -20 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -20 }}
                    className="fixed inset-0 z-50 flex items-center justify-center bg-[#131314]/70 backdrop-blur-sm p-4"
                  >
                    <div className="bg-white rounded-3xl p-8 max-w-lg w-full text-center shadow-[0_30px_60px_-15px_rgba(0,0,0,0.5)] border-4 border-[#001E50]">
                      <PackageCheck className="text-[#001E50] w-20 h-20 mx-auto mb-6 opacity-90 animate-bounce" />
                      <h2 className="text-4xl font-black text-[#001E50] uppercase leading-tight">A peça chegou?</h2>
                      <div className="my-6 bg-gray-50 rounded-2xl p-6 border-2 border-gray-100">
                        <p className="font-mono text-2xl font-black text-[#001E50]">{r.peca?.codigo || "Cód. Desconhecido"}</p>
                        <p className="text-xl font-bold text-gray-600 mt-2">{r.peca?.nome || "Peça Desconhecida"}</p>
                      </div>
                      <button
                        onClick={(e) => handleChegou(r.id, e)}
                        className="w-full bg-[#001E50] hover:bg-[#002E7A] text-white font-black px-8 py-6 rounded-2xl shadow-xl flex items-center justify-center gap-4 active:scale-95 transition-all text-2xl"
                      >
                        <CheckCircle2 size={32} /> Confirmar Recebimento
                      </button>
                    </div>
                  </motion.div>
                ))}
              </AnimatePresence>

              {/* Grid Célula Vidros */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {pecasExibidas.map(p => {
                  const style = getCardStyle(p.cor_logistica);
                  const isPending = registros.find(r => r.peca_id === p.id && r.status === 'pendente' && r.tacto === Number(tactoSelecionado) && r.lado === ladoSelecionado);

                  return (
                    <button
                      key={p.id}
                      onClick={() => setPecaConfirmando(p)}
                      disabled={!!isPending}
                      className={`relative w-full text-left p-8 border-4 border-[#131314] rounded-3xl transition-all shadow-[8px_8px_0px_#131314] hover:translate-x-1 hover:translate-y-1 hover:shadow-[4px_4px_0px_#131314] flex flex-col justify-center min-h-[160px] ${isPending ? 'opacity-50 cursor-not-allowed bg-gray-100 border-gray-300 shadow-none' : style
                        }`}
                    >
                      <div className="relative z-10 flex-1">
                        <p className="text-3xl font-black uppercase tracking-tighter mb-2">{p.nome}</p>
                        <p className="text-xl font-bold font-mono opacity-80">{p.codigo}</p>
                      </div>

                      <div className="mt-6 flex justify-between items-end border-t-2 border-current pt-4 opacity-70 border-opacity-20">
                        <span className="font-bold tracking-widest text-sm">{p.centro_custo || 'CC: 19087'}</span>
                        <span className="font-black capitalize">{p.cor_logistica}</span>
                      </div>

                      {isPending && (
                        <div className="absolute top-4 right-4 bg-[#131314] text-white text-xs font-bold px-3 py-1 rounded-full uppercase">
                          Em Andamento
                        </div>
                      )}
                    </button>
                  );
                })}
              </div>

              {/* Order Confirmation Popup */}
              <AnimatePresence>
                {pecaConfirmando && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="fixed inset-0 z-40 flex items-center justify-center bg-[#131314]/60 backdrop-blur-sm p-4"
                  >
                    <motion.div
                      initial={{ scale: 0.95, y: 20 }}
                      animate={{ scale: 1, y: 0 }}
                      exit={{ scale: 0.95, y: 20 }}
                      className="bg-white rounded-3xl p-8 max-w-md w-full text-center border-4 border-[#131314] shadow-[12px_12px_0px_#001E50]"
                    >
                      <h2 className="text-3xl font-black text-[#001E50] mb-6">Confirmar Pedido</h2>
                      <div className={`p-6 rounded-2xl border-2 mb-8 text-left ${getCardStyle(pecaConfirmando.cor_logistica)}`}>
                        <p className="text-2xl font-black uppercase text-[#131314]">{pecaConfirmando.nome}</p>
                        <p className="text-xl font-bold font-mono text-[#131314]/80 mt-1">{pecaConfirmando.codigo}</p>
                      </div>
                      <div className="flex gap-4">
                        <button
                          onClick={() => setPecaConfirmando(null)}
                          className="flex-1 py-4 bg-gray-100 text-[#131314] font-black border-2 border-[#131314] rounded-2xl"
                        >
                          Cancelar
                        </button>
                        <button
                          onClick={handlePedir}
                          className="flex-1 py-4 bg-[#001E50] text-white font-black border-2 border-[#001E50] rounded-2xl active:scale-95"
                        >
                          Confirmar
                        </button>
                      </div>
                    </motion.div>
                  </motion.div>
                )}
              </AnimatePresence>

            </motion.div>
          )}

        </AnimatePresence>
      </main>
    </div>
  );
}

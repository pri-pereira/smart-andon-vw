import { createClient } from "@supabase/supabase-js";

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || "https://lfnyqsxtfvcwvhvstwoe.supabase.co";
const supabaseKey = import.meta.env.VITE_SUPABASE_ANON_KEY || "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9";

export const supabase = createClient(supabaseUrl, supabaseKey);

export interface CatalogoPeca {
  id: string;
  codigo: string;
  nome: string;
  tacto: number;
  cor_logistica: 'rosa' | 'azul' | 'amarelo' | 'branco';
  centro_custo?: string;
}

export interface ChamadoAndon {
  id: string;
  tacto: number;
  lado: 'LE' | 'LD';
  peca_id: string;
  status: 'pendente' | 'em_transito' | 'concluido';
  criado_em: string;
  concluido_em: string | null;
  // Campos virtuais para facilitar (se for joined via view ou no insert)
  peca?: CatalogoPeca;
}

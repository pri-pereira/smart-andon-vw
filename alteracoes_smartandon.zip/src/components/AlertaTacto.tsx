import { useEffect, useState } from 'react';

interface AlertaTactoProps {
  dataCriacao: string;
  status: string;
}

function formatMMSS(segundos: number) {
  const m = Math.floor(segundos / 60).toString().padStart(2, '0');
  const s = (segundos % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

export default function AlertaTacto({ dataCriacao, status }: AlertaTactoProps) {
  const [segundosDecorridos, setSegundosDecorridos] = useState(0);
  const isFinalizado = status === 'concluido' || status === 'em_transito';

  useEffect(() => {
    if (isFinalizado) return;

    const atualizarContagem = () => {
      const inicio = new Date(dataCriacao).getTime();
      const agora = new Date().getTime();
      const decorridos = Math.floor((agora - inicio) / 1000);
      setSegundosDecorridos(decorridos > 0 ? decorridos : 0);
    };

    atualizarContagem();
    const intervalo = setInterval(atualizarContagem, 1000);
    return () => clearInterval(intervalo);
  }, [dataCriacao, isFinalizado]);

  // Verde (0-5 min), Amarelo (5-10 min), Vermelho (>10 min)
  let corProgressBar = "bg-green-500 shadow-green-500/50";

  if (segundosDecorridos >= 600) { // > 10 min
    corProgressBar = "bg-red-500 shadow-red-500/50";
  } else if (segundosDecorridos >= 300) { // 5-10 min
    corProgressBar = "bg-yellow-400 shadow-yellow-400/50";
  }

  if (status === 'em_transito') corProgressBar = "bg-blue-400 shadow-blue-400/50";
  if (status === 'concluido') corProgressBar = "bg-gray-400 shadow-gray-400/50";

  // Visualmente limitamos a barra em 10 minutos = 100% (600s)
  const percent = Math.min((segundosDecorridos / 600) * 100, 100);

  return (
    <div className="w-full">
      <div className="flex justify-between items-end mb-1">
        <span className={`text-[11px] font-black tracking-widest uppercase ${status === 'pendente' ? 'text-[#001E50]' : 'text-gray-500'}`}>
          {status === 'pendente' ? 'Aguardando Entrega' : status === 'em_transito' ? 'Aguardando Operador' : 'Concluído'}
        </span>
        <span className={`text-base font-mono font-black ${status === 'pendente' ? 'text-[#001E50]' : 'text-gray-500'}`}>
          {formatMMSS(segundosDecorridos)}
        </span>
      </div>
      <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden shadow-inner relative">
        <div
          className={`h-full rounded-full transition-all duration-1000 ${corProgressBar}`}
          style={{ width: `${percent}%` }}
        />
      </div>
    </div>
  );
}

import { useLocation } from "wouter";
import { ArrowLeft } from "lucide-react";

interface HeaderProps {
  title?: string;
  showBackButton?: boolean;
  showNav?: boolean;
}

export default function Header({ title, showBackButton = true, showNav = true }: HeaderProps) {
  const [, setLocation] = useLocation();

  return (
    <header className="w-full bg-[#001E50] border-b-4 border-[#131314] py-4 px-4 md:px-8 flex items-center justify-between shadow-md">
      <div className="flex items-center gap-4">
        {/* Logo VW no canto superior esquerdo de todas as telas */}
        <div className="w-14 h-14 bg-white rounded-full flex items-center justify-center font-black text-[#001E50] text-xl border-2 border-transparent shadow-sm">
          VW
        </div>

        <div className="flex flex-col">
          <h1 className="text-2xl md:text-3xl font-black text-white tracking-widest uppercase">
            Smart Andon
          </h1>
          {title && (
            <p className="text-xs md:text-sm text-blue-200 font-bold uppercase tracking-wider">
              {title}
            </p>
          )}
        </div>
      </div>

      {showNav && showBackButton && (
        <button
          onClick={() => setLocation("/")}
          className="flex items-center gap-2 px-6 py-3 bg-white text-[#001E50] hover:bg-gray-100 rounded-2xl font-black transition-colors shadow-sm active:scale-95 border-2 border-[#131314]"
        >
          <ArrowLeft className="h-5 w-5" />
          <span className="text-sm">Voltar</span>
        </button>
      )}
    </header>
  );
}

import { useState, useCallback, useEffect } from 'react';
import { supabase, type CatalogoPeca } from '@/lib/supabase';

export function useCatalogoPecas() {
    const [pecas, setPecas] = useState<CatalogoPeca[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    const carregarPecas = useCallback(async () => {
        try {
            setLoading(true);
            const { data, error: err } = await supabase
                .from('catalogo_pecas')
                .select('*')
                .order('nome', { ascending: true });

            if (err) throw err;
            setPecas(data || []);
            setError(null);
        } catch (err: any) {
            setError(err.message || 'Erro ao carregar catálogo');
        } finally {
            setLoading(false);
        }
    }, []);

    useEffect(() => {
        carregarPecas();
    }, [carregarPecas]);

    const adicionarPeca = async (novaPeca: Omit<CatalogoPeca, 'id'>) => {
        try {
            const { error: err } = await supabase.from('catalogo_pecas').insert([novaPeca]);
            if (err) throw err;
            await carregarPecas();
            return true;
        } catch (err: any) {
            console.error(err);
            return false;
        }
    };

    const editarPeca = async (id: string, dados: Partial<CatalogoPeca>) => {
        try {
            const { error: err } = await supabase.from('catalogo_pecas').update(dados).eq('id', id);
            if (err) throw err;
            await carregarPecas();
            return true;
        } catch (err: any) {
            console.error(err);
            return false;
        }
    };

    const removerPeca = async (id: string) => {
        try {
            const { error: err } = await supabase.from('catalogo_pecas').delete().eq('id', id);
            if (err) throw err;
            await carregarPecas();
            return true;
        } catch (err: any) {
            console.error(err);
            return false;
        }
    };

    return { pecas, loading, error, adicionarPeca, editarPeca, removerPeca, carregarPecas };
}

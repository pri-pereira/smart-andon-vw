import { useState, useCallback, useEffect } from 'react';
import { supabase, type ChamadoAndon, type CatalogoPeca } from '@/lib/supabase';

interface ChamadoMapeado extends ChamadoAndon {
  peca?: CatalogoPeca;
}

export function useRegistroAndonSupabase() {
  const [registros, setRegistros] = useState<ChamadoMapeado[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const carregarRegistros = useCallback(async () => {
    try {
      setLoading(true);
      // Aqui usamos o peca_id para trazer os dados de catalogo_pecas
      const { data, error: err } = await supabase
        .from('chamados_andon')
        .select(`
          *,
          peca:catalogo_pecas(*)
        `)
        .order('criado_em', { ascending: false });

      if (err) throw err;

      // O Supabase retorna peca como array se for hasMany ou objeto unitário.
      // Assumiremos objeto unitário porque peca_id é uma foreign key.
      setRegistros(data || []);
      setError(null);
    } catch (err: any) {
      setError(err.message || 'Erro ao carregar registros');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    carregarRegistros();
  }, [carregarRegistros]);

  useEffect(() => {
    // Escuta as alterações no chamados_andon
    const subscription = supabase
      .channel('chamados_andon_changes')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'chamados_andon' },
        (payload) => {
          // Quando insere, talvez a peca venha null no realtime se não fizer join. 
          // O ideal é recarregar a lista ou buscar os dados da peca específica
          carregarRegistros();
        }
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'chamados_andon' },
        (payload) => {
          // Atualiza o state local mantendo o objeto peca anterior
          setRegistros((prev) =>
            prev.map((r) =>
              r.id === payload.new.id ? { ...r, ...payload.new } : r
            )
          );
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [carregarRegistros]);

  const adicionarRegistro = async (tacto: number, lado: 'LE' | 'LD', peca_id: string) => {
    try {
      const agora = new Date().toISOString();
      const { error: err } = await supabase
        .from('chamados_andon')
        .insert([{
          tacto,
          lado,
          peca_id,
          status: 'pendente',
          criado_em: agora
        }]);

      if (err) throw err;
      return true;
    } catch (err: any) {
      console.error(err);
      return false;
    }
  };

  const sinalizarEntrega = async (id: string) => {
    try {
      const { error: err } = await supabase
        .from('chamados_andon')
        .update({ status: 'em_transito' }) // Em trânsito representa a entrega realizada pela logística, aguardando double-check do operador
        .eq('id', id);

      if (err) throw err;
      return true;
    } catch (err: any) {
      console.error(err);
      return false;
    }
  };

  const confirmarRecebimento = async (id: string) => {
    try {
      const agora = new Date().toISOString();
      const { error: err } = await supabase
        .from('chamados_andon')
        .update({
          status: 'concluido',
          concluido_em: agora
        })
        .eq('id', id);

      if (err) throw err;
      return true;
    } catch (err: any) {
      console.error(err);
      return false;
    }
  };

  return {
    registros,
    loading,
    error,
    adicionarRegistro,
    sinalizarEntrega,
    confirmarRecebimento,
    carregarRegistros
  };
}
